package mailer;

public class Compactage {

}
