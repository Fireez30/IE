package mailer;

public class Label {

}
