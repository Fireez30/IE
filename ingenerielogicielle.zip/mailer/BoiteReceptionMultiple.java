package mailer;

public class BoiteReceptionMultiple extends BoiteReception {
	
	public BoiteReceptionMultiple(){
		
	}
	
	public String toString(){
		return " Boite Reception Multiple ";
	}
}
