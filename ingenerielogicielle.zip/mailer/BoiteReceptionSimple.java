package mailer;

public class BoiteReceptionSimple extends BoiteReception {
	
	public BoiteReceptionSimple(){
		
	}
	
	public String toString(){
		return " Boite Reception Simple ";
	}
}
