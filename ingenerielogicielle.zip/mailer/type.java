package mailer;

public enum type {
	Travail,Personnel,Loisir
}
